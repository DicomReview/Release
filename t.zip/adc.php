<?php

    require_once "../common/safeBase64.php";
    
    $postArray = file_get_contents("php://input");

    $smtpemailto='lining@dicomreview.com';
    
    require '../common/phpMailer/PHPMailerAutoload.php';
    $mail = new PHPMailer;
    
    //$mail->SMTPDebug = 3;                               // Enable verbose debug output
    
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.mxhichina.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'login@dicomreview.com';                 // SMTP username
    $mail->Password = 'Ali200345';                           // SMTP password
    $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 465;                                    // TCP port to connect to
    
    $mail->setFrom('login@dicomreview.com', 'Dicom Review');
    $mail->addAddress($smtpemailto, '');     // Add a recipient
    //$mail->addAddress('ellen@example.com');               // Name is optional
    //$mail->addReplyTo('info@example.com', 'Information');
    //$mail->addCC('cc@example.com');
    //$mail->addBCC('bcc@example.com');
    
    //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
    $mail->isHTML(true);                                  // Set email format to HTML
    
    $mail->Subject = 'Advice from User';
    
    $mail->Body    = $postArray;
    
    //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    
    if(!$mail->send()) {
        
    }
    
    $htmlString = file_get_contents("adcresult.htm");
    
    
    echo $htmlString;

?>