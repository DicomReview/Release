<?php
    require_once "../common/safeBase64.php";
    
    $result = "{\"expiredTime\":\"2117-06-23 12:30:30\",\"app_latest_version\":\"1.3"}";
    
    $postArray = file_get_contents("php://input");
    if($postArray==null)
    {
        
        $result = encodeSafeBase64($result);
        echo $result;
        
        die("");
    }
    $postArray = decodeSafeBase64($postArray);
    $de_json = json_decode($postArray,true);
    if($de_json ==null)
    {
        
        $result = encodeSafeBase64($result);
        echo $result;
        die("");
    }
    
    $nickname = $de_json['device_info'];
    if($nickname=='mac os')
    {
        $result = "{\"expiredTime\":\"2117-06-23 12:30:30\",\"app_latest_version\":\"1.4.2\"}";
    }else if($nickname=='ios')
    {
        $result = "{\"expiredTime\":\"2117-06-23 12:30:30\",\"app_latest_version\":\"1.3\"}";
    }else if(!(strpos($nickname,'CPU_ABI')==false))
    {
        $result = "{\"expiredTime\":\"2117-06-23 12:30:30\",\"app_latest_version\":\"1.4.2\"}";
    }
    
    
    $result = encodeSafeBase64($result);
    echo $result;
?>