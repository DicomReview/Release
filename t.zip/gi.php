<?php
    require_once "../common/safeBase64.php";
    
    $result = "http://www.dicomreview.com/st/up.php";

    $result = encodeSafeBase64($result);
    echo $result;
    

?>