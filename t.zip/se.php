<?php
    
    
    require_once "../common/safeBase64.php";
    
    
    $postArray = file_get_contents("php://input");
    if($postArray==null)
    {
        echo encodeSafeBase64('{"Status":"1"}');
        die("");
    }
    $postArray = decodeSafeBase64($postArray);
    $de_json = json_decode($postArray,true);
    if($de_json ==null)
    {
        echo encodeSafeBase64('{"Status":"2"}');
        die("");
    }
    
    
    include '../common/mysql.php';
    
    $start = $de_json['start'];
    $end = $de_json['end'];
    $query='select appid,type,statTime from stat where statTime > "' . $start .'" and statTime < "' . $end .'"';
	$result=$mysqli->query($query);
	if(!($result))
	{
		echo '{"Status":"3"}';
		die("");
	}
    if($result->num_rows<=0 || $mysqli->field_count<=0)
    {
        echo '{"Status":"4"}';
		echo $query;
        die("");
    }
    $tmp='{"Status":"0","number":"' . strval($result->num_rows) . '"';
    $index=0;
    for($index=0;$index<$result->num_rows;$index=$index+1)
    {
        $row = $result->fetch_array();
		
		$tmp = $tmp . ',"appid' . strval($index) .'":"' . $row[0] . '"';
		
        $tmp = $tmp . ',"type' . strval($index) .'":"' . $row[1] . '"';
        $tmp = $tmp . ',"time' . strval($index) .'":"' . $row[2] . '"';
    }
	$tmp = $tmp . '}';
    
    echo encodeSafeBase64($tmp);
    
    
?>