<?php
    
    
    require_once "../common/safeBase64.php";
    
    
    $postArray = file_get_contents("php://input");
    if($postArray==null)
    {
        echo encodeSafeBase64('{"Status":"1"}');
        die("");
    }
    $postArray = decodeSafeBase64($postArray);
    $de_json = json_decode($postArray,true);
    if($de_json ==null)
    {
        echo encodeSafeBase64('{"Status":"2"}');
        die("");
    }
    
    
    include '../common/mysql.php';
    
    $msgNumber = $de_json['number'];
    $msgAppid = $de_json['appid'];
    
    $mysqli->autocommit(false);
    
    for ($i=0; $i<$msgNumber;$i++)
    {
        $msgtype='type' . strval($i);
        $msgtime='time' . strval($i);
        
        $msgtype=$de_json[$msgtype];
        $msgtime=$de_json[$msgtime];
        
        $query='insert into stat(appid,type,statTime) values (';
        $query = $query. '"' .$msgAppid. '",' .$msgtype. ',"' .$msgtime. '")';
        $result=$mysqli->query($query);
        if(!$result)
        {
            $mysqli->rollback();
            $mysqli->autocommit(true);
            $mysqli->close();
            
			echo encodeSafeBase64('{"Status":"3"}');
            die("");
        }
        
    }
    
    
    $mysqli->commit();
    $mysqli->autocommit(true);
    $mysqli->close();
    
    
    echo encodeSafeBase64('{"Status":"0"}');
    
    
?>