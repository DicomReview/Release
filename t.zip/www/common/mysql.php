<?php
$db_host="localhost";
$db_user="root";
$db_psw="Mysql123";
$db_name="drstudio";
$mysqli=new mysqli($db_host,$db_user,$db_psw,$db_name);

if($mysqli==null)
{
	echo '{"Status":"false"}';
	die("");
}
?>