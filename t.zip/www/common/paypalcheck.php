<?php
	require_once "safeBase64.php";
    
	
    function payPalCheck($mysqli)
    {
        
        $pp_hostname = "www.paypal.com"; // Change to www.sandbox.paypal.com to test against sandbox
        $auth_token = "8Fy61jjZ5r6G_bcEZTx0O8YENwVsp3ndJXxaTb9VjP7xWh1tRCmE5GJIN50"; //change to real paypal PDT token
        
        // read the post from PayPal system and add 'cmd'
        $req = 'cmd=_notify-synch';
        
        $tx_token = $_GET['tx'];
        
        $req .= "&tx=$tx_token&at=$auth_token";
        
        $URL_PARA = $_SERVER['QUERY_STRING'];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://$pp_hostname/cgi-bin/webscr");
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
        //set cacert.pem verisign certificate path in curl using 'CURLOPT_CAINFO' field here,
        //if your server does not bundled with default verisign certificates.
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array("Host: $pp_hostname"));
        
        $cert = __DIR__ . "./cacert.pem";
        curl_setopt($ch, CURLOPT_CAINFO, $cert);
        
        $res = curl_exec($ch);
		$errmsg = curl_error($ch);
        curl_close($ch);
		
        if(!$res){
			
			
            $curTime = date('Y-m-d H:i:s');
            $ios_receipt_code = encodeSafeBase64($URL_PARA);
            $ios_result_code = "";
            
            $query='select id from paypal_undone where tx="' .$tx_token. '"';
            $result=$mysqli->query($query);
            if(!($result && $result->num_rows>0))
            {
                
                $query = 'insert into paypal_undone (account_id,created_time,tx,receipt,receipt_confirm) values(';
                $query = $query. '0,"' .$curTime. '","' .$tx_token. '","' .$ios_receipt_code. '","' .$ios_result_code. '")';
                $result=$mysqli->query($query);
            }
            
            $tmp['retry_url']=$URL_PARA;
            $tmp['dr_data']=$tx_token;
            $tmp['status']=1;
			$tmp['Status']='1';
            
            $checkResult = json_encode($tmp);
            return $checkResult;
            
            
        }
        
        // parse the data
        $lines = explode("\n", $res);
        $keyarray = array();
        
        if (strcmp ($lines[0], "SUCCESS") == 0) {
           
            $query='delete from paypal_undone where tx="' .$tx_token. '"';
            $mysqli->query($query);
            
            $ios_result="";
            for ($i=1; $i<count($lines)-1;$i++){
                list($key,$val) = explode("=", $lines[$i]);
                
                $keyarray[urldecode($key)] = urldecode($val);
                $ios_result = $ios_result. urldecode($key).":". urldecode($val) .',';
                
            }
            $pay_status = $keyarray['payment_status']; //Completed
            $pay_productID = $keyarray['option_selection1'];
            $pay_custom = $keyarray['custom'];
            $pay_payerEmail = $keyarray['payer_email'];
            
            
            if($pay_status!="Completed")
            {
                $curTime = date('Y-m-d H:i:s');
                $ios_receipt_code = encodeSafeBase64($URL_PARA);
                $ios_result_code = encodeSafeBase64($ios_result);
                
                
                    
                $query = 'insert into paypal_fail (created_time,tx,receipt,receipt_confirm) values(';
                $query = $query. '"' .$curTime. '","' .$tx_token. '","' .$ios_receipt_code. '","' .$ios_result_code. '")';
                $mysqli->query($query);
                

                
                $tmp['custom_url']=$pay_custom;
                $tmp['status']=2;
				$tmp['Status']='2';
                
                $checkResult = json_encode($tmp);
                return $checkResult;
            }
            
            $sql_status=0;
            
            if(strlen($pay_custom)<10)
            {
                $sql_status=1;
            }
            $ios_userid = "";
            $ios_expireDate = "";
            $ios_paidTime = date('Y-m-d H:i:s');
            
            
            if($sql_status==0)
            {
                
                $pay_custom=decodeSafeBase64($pay_custom);
                $de_json = json_decode($pay_custom,true);
                if(!$de_json)
                {
                    $sql_status=1;
                    
                }else{
                    $ios_userid = $de_json['userid'];
                    $ios_paidTime = $de_json['paidTime'];
                }
                if($pay_productID=="One Year")
                {
                    $ios_expireDate = date('Y-m-d H:i:s',strtotime("$ios_paidTime +1 year"));
                }else{
                    $ios_expireDate = date('Y-m-d H:i:s',strtotime("$ios_paidTime +30 day"));
                }
            }
            
            
            $mysqli->autocommit(false);
            if($sql_status==0)
            {
                $query='select id from account where valid =1 and id=' .$ios_userid;
                $result=$mysqli->query($query);
                if(!($result && $result->num_rows>0))
                {
                    $sql_status=1;
                }
            }
            
            if($sql_status==0)
            {
                $curTime = date('Y-m-d H:i:s');
                $ios_receipt_code = encodeSafeBase64($URL_PARA);
                $ios_result_code = encodeSafeBase64($ios_result);
                
                $query = 'insert into payment (account_id,created_time,receipt,receipt_confirm) values(';
                $query = $query. $ios_userid. ',"' .$curTime. '","' .$ios_receipt_code. '","' .$ios_result_code. '")';
                $result=$mysqli->query($query);
                if(!$result)
                {
                    $sql_status=1;
                }
            }
            
            if($sql_status==0)
            {
                
                $query = 'update account set is_paid=1,paid_time="' .$ios_paidTime. '",expire_time="' .$ios_expireDate. '" where id=' .$ios_userid;
                $result=$mysqli->query($query);
                if(!$result)
                {
                    $sql_status=1;
                }
            }
            
            if($sql_status!=0)
            {
			
                $mysqli->rollback();
                $mysqli->autocommit(true);
                
                
                $curTime = date('Y-m-d H:i:s');
                $ios_receipt_code = encodeSafeBase64($URL_PARA);
                $ios_result_code = encodeSafeBase64($ios_result);
                
                $query='select id from paypal_undone where tx="' .$tx_token. '"';
                $result=$mysqli->query($query);
                if(!($result && $result->num_rows>0))
                {
                    if(strlen($ios_userid)==0)
                    {
                        $ios_userid="0";
                    }
                    $query = 'insert into paypal_undone (account_id,created_time,tx,receipt,receipt_confirm) values(';
                    $query = $query. $ios_userid. ',"' .$curTime. '","' .$tx_token. '","' .$ios_receipt_code. '","' .$ios_result_code. '")';
                    $result=$mysqli->query($query);
                }
                $mysqli->close();
                
                $tmp['retry_url']=$URL_PARA;
                $tmp['dr_data']=$tx_token;
                $tmp['status']=1;
				$tmp['Status']='1';
                
                $checkResult = json_encode($tmp);
                return $checkResult;
            }
            
            
            $mysqli->commit();
            $mysqli->autocommit(true);
            $mysqli->close();
            
            $days = (strtotime($ios_expireDate)-strtotime($ios_paidTime))/86400;
            
            $tmp['dr_days']=$days;
            $tmp['expireDate']=$ios_expireDate;
            $tmp['paidTime']=$ios_paidTime;
            $tmp['status']=0;
			$tmp['Status']='0';
            
            $checkResult = json_encode($tmp);
            return $checkResult;
            
            
        }
        else{
            // log for manual investigation
            $ios_result="";
            for ($i=1; $i<count($lines)-1;$i++){
                list($key,$val) = explode("=", $lines[$i]);
                
                $keyarray[urldecode($key)] = urldecode($val);
                $ios_result = $ios_result. urldecode($key).":". urldecode($val) .',';
                
            }
            
            $curTime = date('Y-m-d H:i:s');
            $ios_receipt_code = encodeSafeBase64($URL_PARA);
            $ios_result_code = encodeSafeBase64($ios_result);
            
            $query='select id from paypal_undone where tx="' .$tx_token. '"';
            $result=$mysqli->query($query);
            if(!($result && $result->num_rows>0))
            {
                
                $query = 'insert into paypal_undone (account_id,created_time,tx,receipt,receipt_confirm) values(';
                $query = $query. '0,"' .$curTime. '","' .$tx_token. '","' .$ios_receipt_code. '","' .$ios_result_code. '")';
                $result=$mysqli->query($query);
            }
            
            
            $tmp['retry_url']=$URL_PARA;
            $tmp['dr_data']=$tx_token;
            $tmp['status']=1;
			$tmp['Status']='1';
            
            $checkResult = json_encode($tmp);
            return $checkResult;
            
        }
        return "";
    }

 
?>
