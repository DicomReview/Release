<?php
	function findBase64SafeIndex($ch)
    {
        $base64ListSafe = '2345678ABCKZnopTUDEFGHIaLMNuvwxyz019!-OPQRSfghijklmJVWXYbcdeqrst_';
        $len = strlen($base64ListSafe);
        for($i=0;$i<$len;$i++)
        {
            if(substr($base64ListSafe,$i,1)==$ch)
            {
                return $i;
            }
        }
        return -1;
    }
    function findBase64Index($ch)
    {
        $base64ListSafe = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
        $len = strlen($base64ListSafe);
        for($i=0;$i<$len;$i++)
        {
            if(substr($base64ListSafe,$i,1)==$ch)
            {
                return $i;
            }
        }
        return -1;
    }
    function decodeSafeBase64($safe64String)
    {
        $base64List='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
        
        
        $len = strlen($safe64String);
        $newStr='';
        
        for($i=0;$i<$len;$i++)
        {
            $ch = substr($safe64String,$i,1);
            $index = findBase64SafeIndex($ch);
            if($index<0)
            {
                return '';
            }
            $newStr = $newStr . substr($base64List,$index,1);
            
            
        }
        
        $newStr = base64_decode($newStr);
        
        return $newStr;
        
    }
    function encodeSafeBase64($safe64String)
    {
        $safe64String = base64_encode($safe64String);
        
        $base64List='2345678ABCKZnopTUDEFGHIaLMNuvwxyz019!-OPQRSfghijklmJVWXYbcdeqrst_';
        
        
        $len = strlen($safe64String);
        $newStr='';
        
        for($i=0;$i<$len;$i++)
        {
            $ch = substr($safe64String,$i,1);
            $index = findBase64Index($ch);
            if($index<0)
            {
                return '';
            }
            $newStr = $newStr . substr($base64List,$index,1);
            
            
        }
        
        
        return $newStr;
        
    }

	
?>