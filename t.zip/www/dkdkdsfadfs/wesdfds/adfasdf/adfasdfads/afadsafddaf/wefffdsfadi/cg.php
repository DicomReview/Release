<?php
	require_once "../../../../../../common/safeBase64.php";
    
    $postArray = $_GET['tick'];// file_get_contents("php://input");
	if($postArray==null)
	{
		echo '{"Status":"1"}';
		die("");
	}
	//echo $postArray;
	//die ("");
	$postArray = decodeSafeBase64($postArray);
	//echo $postArray;
	$de_json = json_decode($postArray,true);
	if($de_json ==null)
	{
		echo '{"Status":"2"}';
		die("");
	}

	
	include '../../../../../../common/mysql.php';

	$nickname = $de_json['nickname'];
	$sql = $de_json['sql'];
    
    if($nickname!="lining")
    {
        echo '{"Status":"3"}';
        die("");
    }
	
	if(substr($sql,0,6)=='select')
	{
	}else
	{
	
	die("");
	}
	
	$query=$sql;
	$result=$mysqli->query($query);
	if(!($result))
	{
		echo '{"Status":"4"}';
		die("");
	}
    if($result->num_rows<=0 || $mysqli->field_count<=0)
    {
        echo 'No data.';
        die("");
    }
    echo '<html><body>';
    $index=0;
    for($index=0;$index<$result->num_rows;$index=$index+1)
    {
        $row = $result->fetch_array();
        $col=0;
        
		echo '<p>';
		echo $index+1; echo '.   ';
        for($col=0;$col<$mysqli->field_count;$col=$col+1)
        {
            echo $row[$col];
			echo ',  ';
        }
        echo '</p>';
        
    }
	
    echo '</body></html>';

	
?>