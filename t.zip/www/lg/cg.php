<?php
	require_once "../common/safeBase64.php";
    
    $postArray = file_get_contents("php://input");
	if($postArray==null)
	{
		echo encodeSafeBase64('{"Status":"1"}');
		die("");
	}
	$postArray = decodeSafeBase64($postArray);
	$de_json = json_decode($postArray,true);
	if($de_json ==null)
	{
		echo encodeSafeBase64('{"Status":"2"}');
		die("");
	}

	
	include '../common/mysql.php';

	$nickname = $de_json['nickname'];
	$old = $de_json['old'];
	$new = $de_json['new'];
	
	
	$query='select id,password,valid from account where nickname="' .$nickname. '"';
	$result=$mysqli->query($query);
	if(!($result && $result->num_rows>0))
	{
		echo encodeSafeBase64('{"Status":"3"}');
		die("");
	}
	$row = $result->fetch_array();
	$id=$row[0];
	$passwordDB=$row[1];
	$valid=$row[2];
	
	if($valid == 0 || $passwordDB !=$old)
	{
		echo encodeSafeBase64('{"Status":"4"}');
		die("");
	}
	$query = 'update account set password = "' .$new. '" where id = ' .$id;
	$result=$mysqli->query($query);
	if(!$result)
	{
		
		echo encodeSafeBase64('{"Status":"5"}');
		die("");
	}
	
	
	
	echo encodeSafeBase64('{"Status":"0"}');

	
?>