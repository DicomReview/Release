<?php
	require_once "../common/safeBase64.php";
    
    $postArray = file_get_contents("php://input");
	if($postArray==null)
	{
		echo encodeSafeBase64('{"Status":"1"}');
		die("");
	}
	$postArray = decodeSafeBase64($postArray);
	$de_json = json_decode($postArray,true);
	if($de_json ==null)
	{
		echo encodeSafeBase64('{"Status":"2"}');
		die("");
	}

	
	include '../common/mysql.php';

	$userid = $de_json['userid'];
    
	
	
	$query='select id,password,valid,is_paid,expire_time from account where id=' .$userid;
	$result=$mysqli->query($query);
	if(!($result && $result->num_rows>0))
	{
		echo encodeSafeBase64('{"Status":"3"}');
		die("");
	}
	$row = $result->fetch_array();
	$id=$row[0];
	$passwordDB=$row[1];
	$valid=$row[2];
	$ispaid=$row[3];
	$expireDate=$row[4];
	
	if($valid == 0)
	{
		echo encodeSafeBase64('{"Status":"4"}');
		die("");
	}
	
	
	echo encodeSafeBase64('{"Status":"0","userid":"' .$id. '","paid":"' .$ispaid. '","expireDate":"' .$expireDate. '"}');

	
?>