<?php
	require_once "../common/safeBase64.php";
    
    $postArray = file_get_contents("php://input");
	if($postArray==null)
	{
		echo encodeSafeBase64('{"Status":"1"}');
		die("");
	}
	$postArray = decodeSafeBase64($postArray);
	$de_json = json_decode($postArray,true);
	if($de_json ==null)
	{
		echo encodeSafeBase64('{"Status":"2"}');
		die("");
	}

	
	include '../common/mysql.php';
    
    $mail='';
    $nickname='';
    
    $ismail = $de_json['ismail'];
    if($ismail=="1")
    {
        $mail = $de_json['mail'];
    }else{
        $nickname = $de_json['nickname'];
    }
    
	$password = $de_json['password'];
    $loginTime = $de_json['loginTime'];
    $isMobile = $de_json['isMobile'];
	
	$query='select id,password,valid,is_paid,expire_time,nickname from account where email="' .$mail. '"';
    if($ismail!="1")
    {
        $query='select id,password,valid,is_paid,expire_time,nickname from account where nickname="' .$nickname. '"';
    }
    
	$result=$mysqli->query($query);
	if(!($result && $result->num_rows>0))
	{
		echo encodeSafeBase64('{"Status":"3"}');
		die("");
	}
	$row = $result->fetch_array();
	$id=$row[0];
	$passwordDB=$row[1];
	$valid=$row[2];
	$ispaid=$row[3];
	$expireDate=$row[4];
    $nickname=$row[5];
	
	if($valid == 0 || $passwordDB !=$password)
	{
		echo encodeSafeBase64('{"Status":"4"}');
		die("");
	}
	
    $query = 'update account set pc_login_time = "' .$loginTime. '" where id = ' .$id;
    if($isMobile=="1")
    {
        $query = 'update account set phone_login_time = "' .$loginTime. '" where id = ' .$id;
    }
    $result=$mysqli->query($query);
    if(!$result)
    {
        
        echo encodeSafeBase64('{"Status":"5"}');
        die("");
    }
	
	echo encodeSafeBase64('{"Status":"0","userid":"' .$id. '","nickname":"' .$nickname. '","paid":"' .$ispaid. '","expireDate":"' .$expireDate. '"}');

	
?>