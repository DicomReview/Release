<?php

    
	require_once "../common/safeBase64.php";
    
    
    $postArray = file_get_contents("php://input");
	if($postArray==null)
	{
		echo encodeSafeBase64('{"Status":"1"}');
		die("");
	}
	$postArray = decodeSafeBase64($postArray);
	$de_json = json_decode($postArray,true);
	if($de_json ==null)
	{
		echo encodeSafeBase64('{"Status":"2"}');
		die("");
	}

	
	include '../common/mysql.php';
	
    $mail = $de_json['mail'];
    $nickname = $de_json['nickname'];
    $password = $de_json['password'];
	
	$mysqli->autocommit(false);
    
    $query='select id,password,valid,is_paid,expire_time,nickname from account where nickname="' .$nickname. '"';
    $result=$mysqli->query($query);
    if($result && $result->num_rows>0)
    {
        $mysqli->rollback();
        $mysqli->autocommit(true);
        $mysqli->close();
        
        echo encodeSafeBase64('{"Status":"1"}');
        die("");
    }
    
    $curTime = date('Y-m-d H:i:s');
    
    $query='insert into account(nickname,email,password,valid,is_paid,created_time) values(';
    $query = $query. '"' .$nickname. '","' .$mail. '","' .$password. '",1,0,"' .$curTime. '")';
    $result=$mysqli->query($query);
    if(!$result)
    {
        $mysqli->rollback();
        $mysqli->autocommit(true);
        $mysqli->close();
        
        echo encodeSafeBase64('{"Status":"2"}');
        die("");
    }
    
    $mysqli->commit();
    $mysqli->autocommit(true);
    $mysqli->close();
    
	
	
	echo encodeSafeBase64('{"Status":"0"}');


?>