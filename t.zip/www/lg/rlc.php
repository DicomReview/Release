<?php
	require_once "../common/safeBase64.php";
    
    $postArray = file_get_contents("php://input");
	if($postArray==null)
	{
		echo encodeSafeBase64('{"Status":"1"}');
		die("");
	}
	$postArray = decodeSafeBase64($postArray);
	$de_json = json_decode($postArray,true);
	if($de_json ==null)
	{
		echo encodeSafeBase64('{"Status":"2"}');
		die("");
	}

	
	include '../common/mysql.php';

	$userid = $de_json['userid'];
    $loginTime = $de_json['loginTime'];
    $isMobile = $de_json['isMobile'];
	
	
	$query='select valid,pc_login_time,phone_login_time from account where id=' .$userid;
	$result=$mysqli->query($query);
	if(!($result && $result->num_rows>0))
	{
		echo encodeSafeBase64('{"Status":"3"}');
		die("");
	}
	$row = $result->fetch_array();
	$valid=$row[0];
	$pc=$row[1];
	$phone=$row[2];
    
	
	if($valid == 0)
	{
		echo encodeSafeBase64('{"Status":"4"}');
		die("");
	}
    
    if($isMobile=="1" && $phone==$loginTime)
    {
        echo encodeSafeBase64('{"Status":"0"}');
        die("");
    }else if($isMobile!="1" && $pc==$loginTime)
    {
        echo encodeSafeBase64('{"Status":"0"}');
        die("");
    }
	
	
	echo encodeSafeBase64('{"Status":"5"}');

	
?>