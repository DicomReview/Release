<?php

    
	require_once "../common/safeBase64.php";
    
    
    $postArray = file_get_contents("php://input");
	if($postArray==null)
	{
		echo encodeSafeBase64('{"Status":"1"}');
		die("");
	}
	$postArray = decodeSafeBase64($postArray);
	$de_json = json_decode($postArray,true);
	if($de_json ==null)
	{
		echo encodeSafeBase64('{"Status":"2"}');
		die("");
	}

	
	include '../common/mysql.php';
	
    $smtpemailto = $de_json['mail'];
	
	$password="";
	//echo $smtpemailto;
	$query='select id,password,valid from account where email="' .$smtpemailto. '"';
	$result=$mysqli->query($query);
	if($result && $result->num_rows>0)
	{
		$row = $result->fetch_array();
		$id=$row[0];
		$password=$row[1];
		$valid=$row[2];
		if($valid == 0)
		{
			echo encodeSafeBase64('{"Status":"5"}');
			die("");
		}
		
		
	}else
	{
		echo encodeSafeBase64('{"Status":"6"}');
		die("");
	}
	
	require '../common/phpMailer/PHPMailerAutoload.php';
	$mail = new PHPMailer;
    
    //$mail->SMTPDebug = 3;                               // Enable verbose debug output
    
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.mxhichina.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'login@dicomreview.com';                 // SMTP username
    $mail->Password = 'Ali200345';                           // SMTP password
    $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 465;                                    // TCP port to connect to
    
    $mail->setFrom('login@dicomreview.com', 'Dicom Review');
    $mail->addAddress($smtpemailto, '');     // Add a recipient
    //$mail->addAddress('ellen@example.com');               // Name is optional
    //$mail->addReplyTo('info@example.com', 'Information');
    //$mail->addCC('cc@example.com');
    //$mail->addBCC('bcc@example.com');
    
    //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
    $mail->isHTML(true);                                  // Set email format to HTML
    
    $mail->Subject = 'Email from Dicom Review';
    
    $htmlString = file_get_contents("../common/email_defaultPassword.html");
    $htmlString = str_replace("DR_PASSWORD",$password,$htmlString);
    
    $mail->Body    = $htmlString;
    
    //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    
    if(!$mail->send()) {
        echo encodeSafeBase64('{"Status":"3"}');
		die("");
    } 
	
	
	echo encodeSafeBase64('{"Status":"0"}');


?>