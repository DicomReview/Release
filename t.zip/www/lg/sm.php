<?php

    
	require_once "../common/safeBase64.php";
    
    
    $postArray = file_get_contents("php://input");
	if($postArray==null)
	{
		echo encodeSafeBase64('{"Status":"1"}');
		die("");
	}
	$postArray = decodeSafeBase64($postArray);
	$de_json = json_decode($postArray,true);
	if($de_json ==null)
	{
		echo encodeSafeBase64('{"Status":"2"}');
		die("");
	}

	
	include '../common/mysql.php';
	
    $mail = $de_json['mail'];
    $nickname = $de_json['nickname'];
	
	$mysqli->autocommit(false);
    
    $query='select id,valid from account where nickname="' .$nickname. '"';
    $result=$mysqli->query($query);
    if(!$result || $result->num_rows<1)
    {
        $mysqli->rollback();
        $mysqli->autocommit(true);
        $mysqli->close();
        
        echo encodeSafeBase64('{"Status":"3"}');
        die("");
    }
    
    $row = $result->fetch_array();
    $id=$row[0];
    $valid=$row[1];
    
    if($valid == 0)
    {
        echo encodeSafeBase64('{"Status":"4"}');
        die("");
    }
    
    $query = 'update account set email = "' .$mail. '" where id = ' .$id;
    $result=$mysqli->query($query);
    if(!$result)
    {
        $mysqli->rollback();
        $mysqli->autocommit(true);
        $mysqli->close();
        
        echo encodeSafeBase64('{"Status":"5"}');
        die("");
    }
    
    $mysqli->commit();
    $mysqli->autocommit(true);
    $mysqli->close();
    
	
	
	echo encodeSafeBase64('{"Status":"0"}');


?>