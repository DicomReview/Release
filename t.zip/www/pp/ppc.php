<?php
	require_once "../common/payPalCheck.php";
    require_once "../common/safeBase64.php";
    require_once '../common/mysql.php';
	
    $result = payPalCheck($mysqli);
    
    $result = encodeSafeBase64($result);
    echo $result;
    
    exit;
 
?>
