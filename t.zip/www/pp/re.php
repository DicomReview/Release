<?php
	require_once "../common/payPalCheck.php";
    require_once '../common/mysql.php';
	
    $result = payPalCheck($mysqli);
    
    if(!$result){
        exit;
    }
    $de_json = json_decode($result,true);
    if(!$de_json)
    {
        exit;
        
    }
    if($de_json['status']==0)
    {
        $days = $de_json['expireDate'];
        
        $htmlString = file_get_contents("../common/ivs.htm");
        $htmlString = str_replace("DR_DAYS",$days,$htmlString);
        $htmlString = str_replace("DR_DATA",encodeSafeBase64($result),$htmlString);
        
        echo $htmlString;
        exit;
    }
    
    if($de_json['status']==1)
    {
        $tx_token = $de_json['dr_data'];
        $URL_PARA = $de_json['retry_url'];
        
        $retry = file_get_contents("../common/ivr.htm");
        $retry = str_replace("RETRY_URL",$URL_PARA,$retry);
        $retry = str_replace("DR_DATA",encodeSafeBase64($result),$retry);
        echo $retry;
        
        exit;
    }
    
    if($de_json['status']==2)
    {
        $pay_custom = $de_json['custom_url'];
        
        $htmlString = file_get_contents("../common/ivc.htm");
        $htmlString = str_replace("CUSTOM_URL",$pay_custom,$htmlString);
        echo $htmlString;
        exit;
    }
		
    exit;
 
?>
