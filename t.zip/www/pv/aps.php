<?php
    
	require_once "../common/safeBase64.php";
    require_once '../common/mysql.php';
	
    $postArray = file_get_contents("php://input");
    if(strlen($postArray)<10)
    {
        echo encodeSafeBase64('{"Status":"16"}');
		die("");
    }
    
	
    $jsonstr = decodeSafeBase64($postArray);
    
	
    $strLength = strlen($jsonstr);
    if($strLength<10)
    {
        echo '';
        die('');
    }
    $de_json = json_decode($jsonstr,true);
	if($de_json ==null)
	{
		echo '';
		die("");
	}
  
    $ios_receipt=$de_json['receipt'];
	$ios_userid = $de_json['userid'];
	$ios_expireDate = $de_json['expireDate'];
	$ios_paidTime = $de_json['paidTime'];
	$ios_result = $de_json['ios_result'];
	
	
	$query='select id from account where valid =1 and id=' .$ios_userid;
	$result=$mysqli->query($query);
	if(!($result && $result->num_rows>0))
	{
		$mysqli->close();
		echo encodeSafeBase64('{"Status":"3"}');
		die("");
	}
	
	$curTime = date('Y-m-d H:i:s');
	$ios_receipt_code = encodeSafeBase64($ios_receipt);
	$ios_result_code = encodeSafeBase64($ios_result);
	
	$query = 'insert into payment (account_id,created_time,receipt,receipt_confirm) values(';
	$query = $query. $ios_userid. ',"' .$curTime. '","' .$ios_receipt_code. '","' .$ios_result_code. '")';
	$result=$mysqli->query($query);
	if(!$result)
	{
		$mysqli->close();
		echo encodeSafeBase64('{"Status":"5"}');
		
		die("");
	}
    
	
	$mysqli->autocommit(false);
	
	$query = 'update account set is_paid=1,paid_time="' .$ios_paidTime. '",expire_time="' .$ios_expireDate. '" where id=' .$ios_userid;
	$result=$mysqli->query($query);
	if(!$result)
	{
		$mysqli->rollback();
		$mysqli->autocommit(true);
		$mysqli->close();
		echo encodeSafeBase64('{"Status":"4"}');
		
		die("");
	}
	
	
	$mysqli->commit();
	$mysqli->autocommit(true);
	$mysqli->close();
	
	
	$result = '{"Status":"0"}';
	$result = encodeSafeBase64($result);
    echo $result;

?>