<?php
    
	require_once "../common/safeBase64.php";
    require_once '../common/mysql.php';
	
    $postArray = file_get_contents("php://input");
    if(strlen($postArray)<10)
    {
        echo encodeSafeBase64('{"Status":"16"}');
		die("");
    }
    
	
    $jsonstr = decodeSafeBase64($postArray);
    
	
    $strLength = strlen($jsonstr);
    if($strLength<10)
    {
        echo '';
        die('');
    }
    $de_json = json_decode($jsonstr,true);
	if($de_json ==null)
	{
		echo '';
		die("");
	}
  
	
    $ios_verify_url=$de_json['url'];
    $ios_receipt=$de_json['receipt'];
	$ios_userid = $de_json['userid'];
	$ios_expireDate = $de_json['expireDate'];
	$ios_paidTime = $de_json['paidTime'];
	$ios_productID = $de_json['productID'];
	
	$ios_verify_url = decodeSafeBase64($ios_verify_url);
	$ios_receipt = decodeSafeBase64($ios_receipt);
	
	
    
    if(strlen($ios_receipt)<10 || strlen($ios_verify_url)<10)
    {
		echo encodeSafeBase64('{"Status":"11"}');
		die("");
    }
    
    $defaults = array(
                      CURLOPT_POST => 1,
                      CURLOPT_HEADER => 0,
                      CURLOPT_URL => $ios_verify_url,
                      CURLOPT_FRESH_CONNECT => 1,
                      CURLOPT_RETURNTRANSFER => 1,
                      CURLOPT_FORBID_REUSE => 1,
                      CURLOPT_TIMEOUT => 60,
                      CURLOPT_SSL_VERIFYPEER => FALSE,
                      CURLOPT_POSTFIELDS => $ios_receipt // 苹果购买后返回的票据信息
                      );
    
    
    
    $ch       = curl_init();
    curl_setopt_array($ch, $defaults);
    $ios_result   = curl_exec($ch);
    $errno    = curl_errno($ch);
    $errmsg   = curl_error($ch);
    curl_close($ch);
    
    
    // 判断时候出错，抛出异常
    if ($errno != 0) {
        echo encodeSafeBase64('{"Status":"12"}');
		die("");
    }
	
	$query='select id from account where valid =1 and id=' .$ios_userid;
	$result=$mysqli->query($query);
	if(!($result && $result->num_rows>0))
	{
		$mysqli->close();
		echo encodeSafeBase64('{"Status":"3"}');
		die("");
	}
	
	$curTime = date('Y-m-d H:i:s');
	$ios_receipt_code = encodeSafeBase64($ios_receipt);
	$ios_result_code = encodeSafeBase64($ios_result);
	
	$query = 'insert into payment (account_id,created_time,receipt,receipt_confirm) values(';
	$query = $query. $ios_userid. ',"' .$curTime. '","' .$ios_receipt_code. '","' .$ios_result_code. '")';
	$result=$mysqli->query($query);
	if(!$result)
	{
		$mysqli->close();
		echo encodeSafeBase64('{"Status":"5"}');
		
		die("");
	}
    
	
    $de_json = json_decode($ios_result,true);
	if(!$de_json)
	{
		$mysqli->close();
		echo encodeSafeBase64('{"Status":"20"}');
		die("");
	}
	$receipt_status=$de_json['status'];
	
	
	if($receipt_status!=0)
	{
		$mysqli->close();
		echo encodeSafeBase64('{"Status":"2"}');
		die("");
	}
	
	$receipt_receipt = $de_json['receipt'];
	if(!$receipt_receipt)
	{
		$mysqli->close();
		echo encodeSafeBase64('{"Status":"22"}');
		die("");
	}
	
	
	$receipt_productID = $receipt_receipt['product_id'];
	
	if( $receipt_productID!=$ios_productID)
	{
		$mysqli->close();
		echo encodeSafeBase64('{"Status":"2"}');
		die("");
	}
	
	
	$mysqli->autocommit(false);
	
	$query = 'update account set is_paid=1,paid_time="' .$ios_paidTime. '",expire_time="' .$ios_expireDate. '" where id=' .$ios_userid;
	$result=$mysqli->query($query);
	if(!$result)
	{
		$mysqli->rollback();
		$mysqli->autocommit(true);
		$mysqli->close();
		echo encodeSafeBase64('{"Status":"4"}');
		
		die("");
	}
	
	
	$mysqli->commit();
	$mysqli->autocommit(true);
	$mysqli->close();
	
	
	$result = '{"Status":"0","expireDate":"' .$ios_expireDate. '","result":"' .$ios_result_code. '"}';
	$result = encodeSafeBase64($result);
    echo $result;

?>