<?php
    require_once "../common/safeBase64.php";
    
    $result = "{\"expiredTime\":\"2017-06-23 12:30:30\"}";
    
    $result = encodeSafeBase64($result);
    echo $result;
?>