<?php
    require_once "../common/safeBase64.php";
    
    $result = file_get_contents("../common/data/project.manifest");

    $result = encodeSafeBase64($result);
    echo $result;
    

?>